// ignore_for_file: implementation_imports

const String kWidgetPreviewDtdUri = 'ws://127.0.0.1:51152/52lnJdmNz6E=';
const String kWidgetPreviewService =
    'widget-preview-e1ae4f99-7c0d-4251-8e04-8ba9f3de6a94';
const String kWidgetPreviewScaffoldStream =
    'WidgetPreviewScaffold-e1ae4f99-7c0d-4251-8e04-8ba9f3de6a94';
const String kProjectRootPath = r'C:\Tugas\pemmob\flunds';
