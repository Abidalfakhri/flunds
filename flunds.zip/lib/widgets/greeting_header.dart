import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GreetingHeader extends StatelessWidget {
  final String userName;
  final String businessName;
  final VoidCallback? onAvatarTap;
  final VoidCallback? onNotificationTap;
  final int notificationCount;

  const GreetingHeader({
    super.key,
    required this.userName,
    required this.businessName,
    this.onAvatarTap,
    this.onNotificationTap,
    this.notificationCount = 0,
  });

  String get _initial => userName.trim().isEmpty ? '?' : userName.trim()[0].toUpperCase();

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Halo, $userName', style: Theme.of(context).textTheme.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 2),
              Text(businessName, style: Theme.of(context).textTheme.headlineSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
        const SizedBox(width: 8),
        _NotificationButton(count: notificationCount, onTap: onNotificationTap),
        const SizedBox(width: 10),
        GestureDetector(
          onTap: onAvatarTap,
          child: Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [FlundsColors.accent, FlundsColors.primary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: Text(
              _initial,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 18),
            ),
          ),
        ),
      ],
    );
  }
}

class _NotificationButton extends StatelessWidget {
  final int count;
  final VoidCallback? onTap;
  const _NotificationButton({required this.count, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
          border: Border.all(color: FlundsColors.surfaceLine),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            const Icon(Icons.notifications_outlined, color: FlundsColors.textPrimary, size: 20),
            if (count > 0)
              Positioned(
                top: 9,
                right: 10,
                child: Container(
                  width: 9,
                  height: 9,
                  decoration: const BoxDecoration(color: FlundsColors.expense, shape: BoxShape.circle),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
